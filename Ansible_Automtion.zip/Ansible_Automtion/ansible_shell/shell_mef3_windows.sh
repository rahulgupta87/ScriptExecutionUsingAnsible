!/usr/bin/bash
ansible-playbook /cygdrive/d/Ansible/ansible_playbooks_tasks/playbook_mef3.yml -i /cygdrive/d/Ansible/ansible_playbooks_tasks/inventory_master.txt -e system=windows